#include "element.h"
double Element::compute(){
    return 0;
}
